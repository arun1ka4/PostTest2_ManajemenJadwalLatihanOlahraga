package Service;

import Model.JadwalLatihan;
import java.util.ArrayList;
import java.util.Scanner;

public class MenuJadwal {
    private ArrayList<JadwalLatihan> daftarJadwal = new ArrayList<>();
    private Scanner input = new Scanner(System.in);

    public void tambahJadwal() {
        System.out.print("Masukkan Hari: ");
        String hari = input.nextLine().trim();

        System.out.print("Masukkan Jenis Latihan: ");
        String jenis = input.nextLine().trim();

        System.out.print("Masukkan Waktu (HH:MM): ");
        String waktu = input.nextLine().trim();

        System.out.print("Masukkan Durasi (menit): ");
        int durasi = input.nextInt();
        input.nextLine();

        if (hari.isEmpty() || jenis.isEmpty() || waktu.isEmpty() || durasi <= 0) {
            System.out.println("Input tidak valid, jadwal gagal ditambahkan!");
            return;
        }

        JadwalLatihan jadwal = new JadwalLatihan(hari, jenis, waktu, durasi);
        daftarJadwal.add(jadwal);
        System.out.println("Jadwal berhasil ditambahkan.");
    }

    public void lihatJadwal() {
        if (daftarJadwal.isEmpty()) {
            System.out.println("Belum ada jadwal latihan.");
        } else {
            System.out.println("== Daftar Jadwal Latihan ==");
            for (int i = 0; i < daftarJadwal.size(); i++) {
                System.out.println((i + 1) + ". " + daftarJadwal.get(i));
            }
        }
    }

    public void updateJadwal() {
        lihatJadwal();
        if (daftarJadwal.isEmpty()) return;

        System.out.print("Masukkan nomor jadwal yang ingin diperbarui: ");
        int index = input.nextInt();
        input.nextLine();

        if (index > 0 && index <= daftarJadwal.size()) {
            System.out.print("Masukkan Hari baru: ");
            String hari = input.nextLine().trim();

            System.out.print("Masukkan Jenis Latihan baru: ");
            String jenis = input.nextLine().trim();

            System.out.print("Masukkan Waktu baru (HH:MM): ");
            String waktu = input.nextLine().trim();

            System.out.print("Masukkan Durasi baru (menit): ");
            int durasi = input.nextInt();
            input.nextLine();

            if (hari.isEmpty() || jenis.isEmpty() || waktu.isEmpty() || durasi <= 0) {
                System.out.println("Belum ada jadwal latihan.");
                return;
            }

            daftarJadwal.set(index - 1, new JadwalLatihan(hari, jenis, waktu, durasi));
            System.out.println("Jadwal berhasil diperbarui.");
        } else {
            System.out.println("Nomor tidak valid.");
        }
    }

    public void hapusJadwal() {
        lihatJadwal();
        if (daftarJadwal.isEmpty()) return;

        System.out.print("Masukkan nomor jadwal yang ingin dihapus: ");
        int index = input.nextInt();
        input.nextLine();

        if (index > 0 && index <= daftarJadwal.size()) {
            daftarJadwal.remove(index - 1);
            System.out.println("Jadwal berhasil dihapus.");
        } else {
            System.out.println("Nomor tidak valid.");
        }
    }

    public void cariJadwalByHari() {
        System.out.print("Masukkan hari yang ingin dicari: ");
        String cariHari = input.nextLine().trim();

        boolean ditemukan = false;
        for (JadwalLatihan j : daftarJadwal) {
            if (j.getHari().equalsIgnoreCase(cariHari)) {
                System.out.println(j);
                ditemukan = true;
            }
        }

        if (!ditemukan) {
            System.out.println("Tidak ada jadwal latihan di hari " + cariHari);
        }
    }
}
