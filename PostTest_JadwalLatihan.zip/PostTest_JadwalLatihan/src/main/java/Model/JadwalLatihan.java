package Model;

public class JadwalLatihan {
    private String hari;
    private String jenisLatihan;
    private String waktu;
    private int durasi;

    public JadwalLatihan(String hari, String jenisLatihan, String waktu, int durasi) {
        this.hari = hari;
        this.jenisLatihan = jenisLatihan;
        this.waktu = waktu;
        this.durasi = durasi;
    }

    public String getHari() {
        return hari;
    }

    public void setHari(String hari) {
        this.hari = hari;
    }

    public String getJenisLatihan() {
        return jenisLatihan;
    }

    public void setJenisLatihan(String jenisLatihan) {
        this.jenisLatihan = jenisLatihan;
    }

    public String getWaktu() {
        return waktu;
    }

    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }

    public int getDurasi() {
        return durasi;
    }

    public void setDurasi(int durasi) {
        this.durasi = durasi;
    }

    @Override
    public String toString() {
        return hari + " - " + jenisLatihan + " | " + waktu + " (" + durasi + " menit)";
    }
}
