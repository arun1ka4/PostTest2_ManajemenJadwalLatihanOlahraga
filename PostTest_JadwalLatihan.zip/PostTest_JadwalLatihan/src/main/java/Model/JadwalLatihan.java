package Model;

public class JadwalLatihan {
    private String hari;
    private String jenisLatihan;
    private String waktu;

    public JadwalLatihan(String hari, String jenisLatihan, String waktu) {
        this.hari = hari;
        this.jenisLatihan = jenisLatihan;
        this.waktu = waktu;
    }

    public String getHari() {
        return hari;
    }

    public void setHari(String hari) {
        this.hari = hari;
    }

    public String getJenisLatihan() {
        return jenisLatihan;
    }

    public void setJenisLatihan(String jenisLatihan) {
        this.jenisLatihan = jenisLatihan;
    }

    public String getWaktu() {
        return waktu;
    }

    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }

    @Override
    public String toString() {
        return hari + " - " + jenisLatihan + " | " + waktu;
    }
}
